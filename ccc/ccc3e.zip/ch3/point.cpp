#include "ccc_win.h"

int ccc_win_main()
{  
   cwin << Point(1, 3);
   return 0;
}
